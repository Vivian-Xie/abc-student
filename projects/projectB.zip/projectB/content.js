let tags = document.getElementsByTagName("a");
let eatenOnes = [];
let tongue=document.createElement('div');
document.body.appendChild(tongue);
tongue.className="tongue";


// chrome.windows.onFocusChanged.addListener(function (windowId){
// chrome.runtime.sendMessage({ message: "window fixed" }, function (response) {
//   console.log("hear from backgr:");
    
// });
// })
var lizardImg = chrome.runtime.getURL('www.baidu.com');
let lizardWidth=300;
let lizardHeight=500;
var titleBar = 22;

var displays = [];
chrome.system.display.getInfo(function (ds){
  for (var display of ds){
    displays.push(display.bounds);
  }
});

function bodify(win){
  for (var display of displays){
    if (win.left >= display.left && win.left <= display.left + display.width &&
      win.top >= display.top && win.top <= display.top + display.height){

        var update = false;
        if (win.left - display.left < lizardWidth){
          win.left = display.left + lizardWidth;
          update = true;
        }



        var params = {
          left: win.left,
          top: win.top,
          width: win.width,
          height: win.height
        };
        

        if (update){
          chrome.windows.update(win.id, params, function (win){
            appendliz(win);
          });
        } else {
          appendliz(win);
        }
        break;
    }
  }
}

function appendliz(win){
  var lizardTop = win.top + (win.height / 4);
  var lizard = win.left - lizardWidth;
  lizard.moveTo(lizardLeft, lizardTop);
  setTimeout(checkBod, 500);
}



var currentWin;


chrome.windows.getCurrent({}, function (win){
  currentWin = win;
  lizard = window.open(lizardImg, '', 'width=' + lizardWidth + ', height=' + lizardHeight);
});

var refocusing = false;
chrome.windows.onFocusChanged.addListener(function (windowId){
  if ( windowId != -1 && appendageIds.indexOf(windowId) == -1 && !refocusing){
    refocusing = true;
    for (var id of appendageIds){
      chrome.windows.update(id, {focused: true});
    }
    chrome.windows.update(windowId, {focused: true}, function (){
      refocusing = false;
      
      chrome.windows.get(windowId, {}, function (win){
        currentWin = win;
        bodify(win);
      });
    });

  }
});

// ready = false;
// appendageIds = [];
// chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse){
//   appendageIds.push(sender.tab.windowId);
//   if (appendageIds.length >= 5){
//     ready = true;
//   }
// });

function checkBod(){
  chrome.windows.get(currentWin.id, {}, function (win){
    if (win.left != currentWin.left || win.top != currentWin.top ||
      win.width != currentWin.width || win.height != currentWin.height){
        bodify(win);
    } else {
      setTimeout(checkBod, 500);
    }
  });
}

setTimeout(checkBod, 500);







// const getOffset = (el) => {
//   const rect = el.getBoundingClientRect();
//   return {
//     left: rect.left,
//     top: rect.top,
//     width: rect.width,
//     height: rect.height
//   };
// }

// for (let i = 0; i < tags.length; i++) {
  
//   // find out which tags are actualy relevant (eg not empty strings)
//   if (tags[i].textContent != "") {
//     tags[i].addEventListener("mouseover", (e) => {
      
      
//       eatenOnes.push({
//         text: tags[i].textContent,
//         link: tags[i].href
//       });
//       // console.log(eatenOnes);
//       setTimeout(() => {
//         tags[i].style.visibility = "hidden";
//         tags[i].style.pointerEvents = "none";
//       }, 500);

//       console.log("Leon's method"+getOffset(tags[i]).left+"+"+getOffset(tags[i]).top);
//       // console.log(getOffset(tags[i]).left + "+" + getOffset(tags[i]).top);
//       // set the initial center pos of the link the lizard will eat
//       let tagX=getOffset(tags[i]).left+getOffset(tags[i]).width/2;
//       let tagY=getOffset(tags[i]).top+getOffset(tags[i]).height/2;

//       let tongueX=0;
//       // can be changed according to the lizard
//       let tongueY=window.innerHeight/2;
//       let a = tagX - tongueX;
//       let b = tagY - tongueY; 
//       // keep the tongue grow and shrink according to the pos of a,b
//       let tongueLength = Math.sqrt(a*a + b*b)
//       // console.log("rotation angle is "+(Math.atan(tongueWidth/tongueHeight))*180/Math.PI);
      
//       // rotation center and angle
//       tongue.style.backgroundImage.size="100%"
//       tongue.style.transformOrigin="0 50%"

//       tongue.style.width=tongueLength+"px"
//       setTimeout(()=>{
//         tongue.style.width="0px"
        
//       },500)
//       // tongue.style.width=(tongxueWidth**2+tongueHeight**2)*0.5+"px";

//       // angle between two points:  Math.atan2(p2.y - p1.y, p2.x - p1.x);
//       let angle = (Math.atan2(tagY-tongueY, tagX-tongueX)) * 180 / Math.PI;
//       // tags[i].innerHTML+=angle;
//       tongue.style.transform="rotate("+angle+"deg)"
//       chrome.runtime.sendMessage(
//         { msg: eatenOnes }
//       );
//     })
    
//   }
// }
