# selfie cam?
![screenshot](img.jpg)
## Description

## Challenges, solutions, compromises and shortcomings

## Compromises and shortcomings

