console.log("This is a new page");

let button=document.getElementById("btn")
let input=document.getElementById("inputt")
let disappear=document.getElementById("disappear")
let appear=document.getElementById("appear")

// 把数据送到server里

/*
button.addEventListener("click",()=>{
    // console.log("yes");
    // disappear.style.display="none"
    let text = input.value;
    let route = "/sendAnswer?answer="+text;
    console.log(route)
    fetch(route);
    // console.log(__dirname);
    // if (input.value=="Waiting for my favorite songs"){
    //     window.location.href="http://127.0.0.1:5501/mini-projects/mini-project6/fetchTest/accessible/player/index.html";
    //     window.location.href=" path.join(__dirname,'player/index.html";
    // }


})*/

button.addEventListener("click",()=>{
    let text = input.value;
    let route = "/sendAnswer?answer="+text;
    fetch(route);
    // if(password.value==="china"|| password.value=="China"){
    //   window.location.href="/entrance?password="+password.value;
    // }
  })